package OOPShapeExcercise;

public class Shape {
    private double s;

    public Shape(){

    }

    public double getS() {
        return s;
    }

    public void setS(double s) {
        this.s = s;
    }

    public Shape(double s) {
        this.s = s;
    }
    public void total(){
        System.out.println("This is the total of the ");
    }
}
